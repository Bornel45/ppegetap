package org.ldv.sio.getap;

import java.sql.Date;


public class Exemple {
	 DemandeValidationConsoTempsAccPers dvctap;
	

	static public void main(String[] args) {
		Classe classeSio22  = new Classe(1,"sio22");
		
		User eleve1 =  new User((long) 1,"Roy","Baptiste",classeSio22,"eleve","broy","broy","baptiste.r45@laposte.net");
		User professeur1 =  new User((long) 2,"Capuozzo","Olivier",classeSio22,"professeur","Ocapu","Ocapu","Ocapu@laposte.net");
		
		AccPersonalise accPerso = new AccPersonalise(1,"Salon du libre",1,(long) 1);
		
		Date dateacc = Date.valueOf("07-10-2012");
		
		DemandeValidationConsoTempsAccPers dvctap = new DemandeValidationConsoTempsAccPers((long) 1, "2012-2013", dateacc, 20, professeur1,accPerso,eleve1, 0);
		System.out.println(dvctap);
		
		dvctap.setEtat(4);
		System.out.println(dvctap);
		
		dvctap.setEtat(32);
		System.out.println(dvctap);
		
		dvctap.setEtat(4);
		System.out.println(dvctap);
		
		dvctap.setEtat(2048);
		System.out.println(dvctap);
		
		dvctap.setEtat(2);
		System.out.println(dvctap);
		
		dvctap.setEtat(32);
		System.out.println(dvctap);
	}
}
