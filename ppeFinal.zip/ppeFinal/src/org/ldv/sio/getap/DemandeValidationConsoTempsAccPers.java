
package org.ldv.sio.getap;

import java.sql.Date;
/**
 * Demande de validation d'un temps d'accompagnement personnalisé
 * 
 */
public class DemandeValidationConsoTempsAccPers {
	private static final int DATE_MODIFIEE =  1024;

	private static final int DUREE_MODIFIEE =  2048;

	private static final int AP_MODIFIEE =  4096;

	/**
	 * Identifiant de la DCTAP
	 */
	private Long id;

	/**
	 * Année scolaire de la demande, par exemple "2011-2012"
	 */
	private String anneeScolaire;

	/**
	 * Date de réalisation de l'accompagnement
	 * 
	 */
	private java.sql.Date dateAction;

	/**
	 * Nombre de minutes d'accompagnement personnalisé à valider
	 */
	private Integer minutes;

	/**
	 * 
	 * Professeur ayant assuré l'accompagnement personnalisé
	 * 
	 */
	private User prof;

	/**
	 * 
	 * Nature de l'accompagnement personnalisé associé à la demande
	 * 
	 */
	private AccPersonalise accPers;

	/**
	 * 
	 * Identifiant de l'élève ayant réalisé l'accompagnement personnalisé
	 * 
	 */
	private User eleve;

	/**
	 * 
	 */
	private int etat;

	/**
	 * constructeur par défaut
	 */
	public DemandeValidationConsoTempsAccPers() {

	}

	/**
	 * Constructeur permettant de créer une demande complète.
	 * 
	 * @param id peut être null (moment de la creation)
	 *            
	 * @param anneeScolaire
	 * @param date
	 * @param minutes
	 * @param prof
	 * @param accPers
	 * @param eleve 
	 * @param etat
	 */
	public DemandeValidationConsoTempsAccPers(Long id, String anneeScolaire, Date date, Integer minutes, User prof, AccPersonalise accPers, User eleve, int etat) {
		super();
		this.id = id;
		this.anneeScolaire = anneeScolaire;
		this.dateAction = date;
		this.minutes = minutes;
		this.prof = prof;
		this.accPers = accPers;
		this.eleve = eleve;
		this.etat = etat;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAnneeScolaire() {
		return anneeScolaire;
	}

	public void setAnneeScolaire(String anneeScolaire) {
		this.anneeScolaire = anneeScolaire;
	}

	public java.sql.Date getDateAction() {
		return dateAction;
	}

	public void setDateAction(java.sql.Date date) {
		this.dateAction = date;
	}

	public Integer getMinutes() {
		return minutes;
	}

	public void setMinutes(Integer minutes) {
		this.minutes = minutes;
	}

	public User getProf() {
		return prof;
	}

	public void setProf(User prof) {
		this.prof = prof;
	}

	public AccPersonalise getAccPers() {
		return accPers;
	}

	public void setAccPers(AccPersonalise accPers) {
		this.accPers = accPers;
	}

	public User getEleve() {
		return eleve;
	}

	public void setEleve(User eleve) {
		this.eleve = eleve;
	}

	public int getEtat() {
		return etat;
	}

	/**
	 * Permet de modifier l'état de la demande
	 * 
	 * @param etat
	 *            prend ses valeur dans :
	 *            <ul>
	 *            <li>0 - demande créée par l'élève</li>
	 *            <li>1 - demande acceptée par l'élève aprés modification du
	 *            professeur</li>
	 *            <li>2 - demande rejetée par l'élève aprés modification du
	 *            professeur</li>
	 *            <li>4 - demande modifiée par l'élève</li>
	 *            <li>8 - demande annulée par l'élève</li>
	 *            <li>32 - demande validée par le professeur</li>
	 *            <li>64 - demande refusée par le professeur</li>
	 *            <li>DATE_MODIFIEE - demande où la date a été modifiée par le professeur
	 *            </li>
	 *            <li>DUREE_MODIFIEE - demande où la durée a été modifiée par le
	 *            professeur</li>
	 *            <li>AP_MODIFIEE - demande où l'accompagnement personnalisé a été
	 *            modifiée par le professeur</li>
	 *            </ul>
	 * Si les differents chemin du cycle de vie sont incorrectes, genere une exception voila c'est tout
	 */
	public void setEtat(int etat) {
			if(this.isModifEleve(etat) || isModifEleveBoucle(etat) ||  isAnnuleEleve(etat) || isRefuseprof(etat) || isValidProf(etat) || isValidModifProf(etat) || isModifProf(etat) || isValidElev(etat) || isRefusEleve(etat)){
				this.etat = etat;
			}else{
				throw new DVCTAPException("nan je crois pas nan");
				
			}
		
	}



	@Override
	public String toString() {
		return "DemandeConsoTempsAccPers [id=" + id + ", anneeScolaire="
				+ anneeScolaire + ", dateAction=" + dateAction + ", minutes="
				+ minutes + ", prof=" + prof + ", accPers=" + accPers
				+ ", eleve=" + eleve + ", etat=" + etat + "]";
	}


	/**
	 * Permet de verifier si l'objet est a son etat initial
	 * */
	public boolean isEtatInitial() {
		// TODO Auto-generated method stub
		return this.etat == 0;
	}

	/**
	 * Permet de verifier si la transition entre l'etat initial et la modification par l'eleve est correct
	 * @param etat
	 * */

	public boolean isModifEleve(int etat){
		if (this.etat == 0 && (etat == 4)){
			return true;
		}
		else{
			return false;
		}
	}

	/**
	 * Permet de verifier si la transition entre la modification eleve et la modification par l'eleve est correct
	 * @param etat
	 * */
	
	public boolean isModifEleveBoucle(int etat){
		if (this.etat == 4 && (etat == 4)){
			return true;
		}
		else{
			return false;
		}
	}

	/**
	 * Permet de verifier si la transition entre la modification eleve ou l'etat initial et l'annulation par l'eleve est correct
	 * @param etat
	 * */
	
	public boolean isAnnuleEleve(int etat){
		if ((this.etat == 0 || this.etat ==4)  && (etat == 8)){
			return true;
		}
		else{
			return false;
		}
	}

	/**
	 * Permet de verifier si la transition entre la modification eleve ou l'etat initial et le refus par le prof est correct
	 * @param etat
	 * */
	
	public boolean isRefuseprof(int etat){
		if ((this.etat == 0 || this.etat ==4)  && (etat == 64)){
			return true;
		}
		else{
			return false;
		}
	}

	/**
	 * Permet de verifier si la transition entre la modification eleve ou l'etat initial et la validation par le prof est correct
	 * @param etat
	 * */
	
	public boolean isValidProf(int etat){
		if ((this.etat == 0 || this.etat ==4)  && (etat == 32)){
			return true;
		}
		else{
			return false;
		}
	}

	/**
	 * Permet de verifier si la transition entre la modification eleve ou l'etat initial et la modif par le prof est correct
	 * @param etat
	 * */
	
	public boolean isValidModifProf(int etat){
		if ((this.etat == 0 || this.etat ==4)  && (etat == DATE_MODIFIEE || etat== DUREE_MODIFIEE || etat == AP_MODIFIEE)){
			return true;
		}
		else{
			return false;
		}
	}

	/**
	 * Permet de verifier si la transition entre la modification par le prof et la modification par le prof est correct
	 * @param etat
	 * */
	
	public boolean isModifProf(int etat){
		if ((this.etat == DATE_MODIFIEE || this.etat ==DUREE_MODIFIEE || this.etat == AP_MODIFIEE)  && (etat == DATE_MODIFIEE || etat== DUREE_MODIFIEE || etat == AP_MODIFIEE)){
			return true;
		}
		else{
			return false;
		}
	}

	/**
	 * Permet de verifier si la transition entre la modification par le prof et la validation par l'eleve est correct
	 * @param etat
	 * */
	
	public boolean isValidElev(int etat){
		if ((this.etat == DATE_MODIFIEE || this.etat ==DUREE_MODIFIEE || this.etat == AP_MODIFIEE)  && (etat == 1)){
			return true;
		}
		else{
			return false;
		}
	}

	/**
	 * Permet de verifier si la transition entre la modification par le prof et le refus par l'eleve est correct
	 * @param etat
	 * */
	
	public boolean isRefusEleve(int etat){
		if ((this.etat == DATE_MODIFIEE || this.etat ==DUREE_MODIFIEE || this.etat == AP_MODIFIEE)  && (etat == 2)){
			return true;
		}
		else{
			return false;
		}
	}



}
