package org.ldv.sio.getap;

public class DVCTAPException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public DVCTAPException(String message) {
		super(message);
	}

}