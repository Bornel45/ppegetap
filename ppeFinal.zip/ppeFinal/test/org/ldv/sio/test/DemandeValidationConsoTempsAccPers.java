package org.ldv.sio.test;

import static org.junit.Assert.*;

import java.sql.Date;

import org.junit.Test;


public class DemandeValidationConsoTempsAccPers {
	Classe classeSio22  = new Classe(1,"sio22");
	
	User eleve1 =  new User((long) 1,"Roy","Baptiste",classeSio22,"eleve","broy","broy","baptiste.r45@laposte.net");
	User professeur1 =  new User((long) 2,"Capuozzo","Olivier",classeSio22,"professeur","Ocapu","Ocapu","Ocapu@laposte.net");
	
	AccPersonalise accPerso = new AccPersonalise(1,"Salon du libre",1,(long) 1);
	
	Date dateacc = Date.valueOf("07-10-2012");
	
	DemandeValidationConsoTempsAccPers dvctap = new DemandeValidationConsoTempsAccPers((long) 1, "2012-2013", dateacc, 20, professeur1,accPerso,eleve1, 0);



	@Test
	public void testEtatInitial() {
		assertTrue("Etat initial", dvctap.isEtatInitial());
		}
	
	@Test
	public void test() {		
		try{
			dvctap.setEtat(4);
			assertTrue("Etat 4", dvctap.setEtat(4));
		} catch (DVCTAPException e){
		try{
			dvctap.setEtat(1024);
			assertTrue("Etat 4", dvctap.setEtat(1024));
			} catch (DVCTAPException e){
		try{
			dvctap.setEtat(1024);
			assertTrue("Etat 8", dvctap.setEtat(8));
			} catch (DVCTAPException e)
		}
	}
}
}
